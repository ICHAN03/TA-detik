<?php 
if($this->session->userdata('role_id')!=1){
    redirect(base_url());
}
?>
aaaaaaaaaa