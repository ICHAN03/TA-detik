
<!-- Modal Tambah Data -->

<div class="modal fade" id="tambah" tabindex="-1" role="dialog" aria-labelledby="TambahLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"></span>
                </button>
            </div>
           
            <form action="<?= site_url('admin/tambahPendaftaran') ?>" method="post">
            <!-- <input type="text" nama="query" placeholder="Cari"/>
            <input type="submit" name="cari" value="Search"/> -->
                <div class="modal-body">
                    <div class="form-group">
                   
                    <label>Tanggal Kunjungan</label>
                        <input type="date" class="form-control" name="tanggal" autocomplete="off">
                        <label>No Rekam Medis</label>
                        <select name="medis" autocomplete="off" class="form-control">
                            <option value="RM Lama">RM Lama</option>
                            <option value="RM Baru">RM Baru</option>
                        </select>
                        <!-- <input type="text" class="form-control" name="medis" autocomplete="off"> -->
                        <label>Nama Lengkap</label>
                        <input type="text" class="form-control" name="nama" autocomplete="off">
                        <label>No KK</label>
                        <input type="text" class="form-control" name="nkk" autocomplete="off">
                        <label>Nama Penanggung Jawab</label>
                        <input type="text" class="form-control" name="penanggungjawab" autocomplete="off">
                        <label>NIK</label>
                        <input type="text" class="form-control" name="NIK" autocomplete="off">
                        <label>Alamat</label>
                        <input type="text" class="form-control" name="alamat" autocomplete="off">
                        <label>Tanggal Lahir</label>
                        <input type="date" class="form-control" name="tgllahir" autocomplete="off">
                        <label>Umur</label>
                        <input type="text" class="form-control" name="umur" autocomplete="off">
                        <label>Jenis Kelamin</label>
                        <select name="jk" autocomplete="off" class="form-control">
                        <option value="Laki-Laki">Laki-Laki</option>
                        <option value="Perempuan">Perempuan</option>
                        </select>
                        <!-- <input type="text" class="form-control" name="jk" autocomplete="off"> -->
                        <label>No Identitas</label>
                        <input type="text" class="form-control" name="noidentitas" autocomplete="off">
                        <label>Agama</label>
                        <select name="agama" autocomplete="off" class="form-control">
                            <option value="Hindu">Hindu</option>
                            <option value="Islam">Islam</option>
                            <option value="Keristen">Kristen</option>
                            <option value="Buddha"> Buddha</option>
                        </select>
                        <!--input type="text" class="form-control" name="agama" autocomplete="off"-->
                        <label>Pendidikan</label>
                        <select name="pendidikan" autocomplete="off" class="form-control">
                            <option value="Belu Sekolah">Belum Sekolah</option>
                            <option value="Taman Kanak-Kanak">TK</option>
                            <option value="Sekolah Dasar">SD</option>
                            <option value="sekolah Menengah Pertama">SMP</option>
                            <option value="Sekolah Menengah Atas">SMA</option>
                            <option value="Mahasiswa">Mahasiswa</option>
                            <option value="Mahasiswa">Berkerja</option>
                            <option value="Pengangguran">Pengangguran</option>
                            <option value="Pensiun">Pensiun</option>
                            
                            </select>
                        <!-- <input type="text" class="form-control" name="pendidikan" autocomplete="off"> -->
                        <label>Status Perkawinan</label>
                        <!-- <input type="text" class="form-control" name="perkawinan" autocomplete="off"> -->
                       <select name="perkawinan" autocomplete="off" class="form-control">
                                <option value="Belum Menikah">Belum Menikah</option>
                                <option value="Menikah">Menikah</option>
                       </select>
                        <label>No Kartu JKN</label>
                        <input type="text" class="form-control" name="jkn" autocomplete="off">
                        <label>Unit Pelayanan</label>
                        <select name="unit" autocomplete="off" class="form-control">
                                <option value="Poli Umum">POLI UMUM</option>
                                <option value="Poli Gigi">POLI Gigi</option>
                                <option value="Poli KIA/KB">POLI KIA/KB</option>
                                <option value="Poli MTBS">POLI MTBS</option>
                                <option value="Poli PKPR">POLI PKPR</option>
                                
                       </select>
                        <label>Cara Bayar</label>
                        <select name="bayar" id="" autocomplete="off" class="form-control">
                                <option value="BPJS">BPJS</option>
                                <option value="Tunai">Tunai</option>
                                <option value="Askes">ASKES</option>

                        </select>
                        <!-- <input type="text" class="form-control" name="bayar" autocomplete="off"> -->
                        
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" name="insertdata" class="btn btn-warning">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- DataTales Example -->

<div class="container-fluid">

<!-- Page Heading -->
<!-- <h6 class="m-0 font-weight-bold text-primary-800">PENDFTARAN</h6> -->

<h1 class="h3 mb-2 text-primary-800">PENDAFTARAN</h1>
<!-- <p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p> -->

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <!-- <h6 class="m-0 font-weight-bold text-primary">Tambah</h6> -->
    <button type="button" class="btn btn-warning  mb-3" data-toggle="modal" data-target="#tambah"><i
                    class="fas fa-fw fa-plus-circle"></i>Tambah</button>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <div class="row">
              <div class="col-sm-12 col-md-6">
                  <div class="dataTables_length" id="dataTable_length">
                      <label>Show</label>
                      <select name="dataTable_length" aria-contrlos="dataTable" class="custom-select custom-select form-control form-control-sm" id="">
                          <option value="10">10</option>
                          <option value="10">50</option>
                          <option value="10">100</option>

                      </select>
                      entries
                  </div>
              </div>
              <label >Search:
              <input type="search" class="form-control form-contol-sm" placeholder aria-control="dataTable">

              </label>
          </div>
      <!-- <label>Show 
          <select name="dataTable_length" aria-control="dataTable" class="custom-select custom-select-sm" id="">Entries</select>  
    </label> -->
<!-- <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">PENDFTARAN</h6>
    </div>
  
    <div class="card-body">
        <div class="table-responsive">
            <?php
            if ($this->session->flashdata('message')) {
                echo "<div class='alert alert-primary'><button type='button' class='close' data-dismiss='alert' aria-label='close'><span aria-hidden='true'>&times;</span></button>" . $this->session->flashdata('message') . "</div>";
            }
            ?>
            <button type="button" class="btn btn-warning  mb-3" data-toggle="modal" data-target="#tambah"><i
                    class="fas fa-fw fa-plus-circle"></i>Tambah</button>
            <table class="table table-bordered" id="exttable" width="100%" cellspacing="0">
            -->
                    <tr>
                        <th>No</th>
                        <th>Tangaal Kunjungan</th>
                        <th>No Rekam Medis</th>
                        <th>Nama Lengkap</th>
                        <th>No KK</th>
                        <th>Nama Penangung Jawab</th>
                        <th>NIK</th>
                        <th>Alamat</th>
                        <th>Tanggal Lahir</th>
                        <th>Jenis Kelamin</th>
                        <th>No Identitas</th>
                        <th>Agama</th>
                        <th>Pendidikan</th>
                        <th>Status Perkawinan</th>
                        <th>No Kartu JKN</th>
                        <th>Unit Pelayanan</th>
                        <th>Cara Bayar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
          
              
        
                <?php $i = 1;?>
                <?php foreach ($pendaftaran as $apa): ?>
               
                <tr>
                <td><?=$i++;?></td>
                <td><?= $apa->tanggal_kunjungan ?></td>
                <td><?= $apa->no_rekam_medis ?></td>
                <td><?= $apa->nama_lengkap ?></td>
                <td><?= $apa->nokk?></td>
                <td><?= $apa->nama_penanggung_jawab?></td>
                <td><?= $apa->NIK ?></td>
                <td><?= $apa->alamat ?></td>
                <td><?= $apa->tanggal_lahir ?></td>
                <td><?= $apa->jenis_kelamin ?></td>
                <td><?= $apa->no_identitas ?></td>
                <td><?= $apa->agama ?></td>
                <td><?= $apa->pendidikan ?></td>
                <td><?= $apa->status_perkawinan ?></td>
                <td><?= $apa->no_kartu_jkn ?></td>
                <td><?= $apa->unit_pelayanan ?></td>
                <td><?= $apa->cara_pembayaran ?></td>
                    
                        <td>
                        <a href="<?= site_url('admin/updateP/' .$apa->id) ?>" class="btn btn-warning"><i
                                    class="far fa-fw fa-edit"></i></a>
                        <a onclick="return confirm ('yakin?')"
                                href="<?= site_url('admin/hapusPasien/' .$apa->id ) ?>" class="btn btn-danger"><i
                                    class="fas fa-fw fa-trash-alt"></i></a>
                        </td>
                    </tr>
                    <?php endforeach ;?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
            