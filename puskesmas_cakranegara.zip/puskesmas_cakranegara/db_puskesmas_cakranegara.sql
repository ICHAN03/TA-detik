-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2020 at 07:52 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_puskesmas_cakranegara`
--

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `role` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `role`) VALUES
(1, 'Pendaftaran'),
(2, 'Adminitrasi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_data_pasien`
--

CREATE TABLE `tbl_data_pasien` (
  `id` int(11) NOT NULL,
  `tanggal_kunjungan` date NOT NULL,
  `no_rekam_medis` varchar(200) NOT NULL,
  `nama_lengkap` varchar(200) NOT NULL,
  `nokk` varchar(200) NOT NULL,
  `nama_penanggung_jawab` varchar(200) NOT NULL,
  `NIK` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `umur` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(200) NOT NULL,
  `no_identitas` varchar(11) NOT NULL,
  `agama` varchar(200) NOT NULL,
  `pendidikan` varchar(200) NOT NULL,
  `status_perkawinan` varchar(200) NOT NULL,
  `no_kartu_jkn` varchar(200) NOT NULL,
  `unit_pelayanan` varchar(200) NOT NULL,
  `cara_pembayaran` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_data_pasien`
--

INSERT INTO `tbl_data_pasien` (`id`, `tanggal_kunjungan`, `no_rekam_medis`, `nama_lengkap`, `nokk`, `nama_penanggung_jawab`, `NIK`, `alamat`, `tanggal_lahir`, `umur`, `jenis_kelamin`, `no_identitas`, `agama`, `pendidikan`, `status_perkawinan`, `no_kartu_jkn`, `unit_pelayanan`, `cara_pembayaran`) VALUES
(46, '2016-02-09', 'RM', 'Ni Made Sri Utari', '', '', '2983', 'jl apa aja boleh', '1996-05-07', '45', 'Laki-Laki', '896765', 'Hindu', 'Belu Sekolah', 'Belum Menikah', 'siuey', 'Poli Gigi', 'Tunai'),
(49, '0000-00-00', 'RM Lama', '', '', '', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'BPJS'),
(50, '2020-07-08', 'RM Lama', 'sdfds', '', 'hgh', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'BPJS'),
(51, '0000-00-00', 'RM Lama', '', '', '', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'DLL'),
(52, '0000-00-00', 'RM Lama', '', '1234567890', '', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'BPJS'),
(53, '2020-07-31', 'RM Lama', 'sad', '', '', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'Tunai'),
(54, '0000-00-00', 'RM Baru', 'jhgh', '', 'jhgj', 'kjhj', 'hjgh', '2020-07-10', 'hgh', 'Laki-Laki', 'hgh', 'Hindu', 'Belu Sekolah', 'Belum Menikah', 'hgfhg', 'Poli Umum', 'Askes'),
(55, '2020-07-02', 'RM Lama', '', '', '', '', '', '0000-00-00', '', 'Laki-Laki', '', 'Hindu', 'Belu Sekolah', 'Belum Menikah', '', 'Poli Umum', 'BPJS');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gigi`
--

CREATE TABLE `tbl_gigi` (
  `id` int(11) NOT NULL,
  `no_rekam_medis` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `anamnesa` varchar(200) NOT NULL,
  `physic_diagnostic` varchar(200) NOT NULL,
  `tensi` varchar(200) NOT NULL,
  `nadi` varchar(200) NOT NULL,
  `suhu` varchar(200) NOT NULL,
  `laju_pernafasan` varchar(200) NOT NULL,
  `tinggi_badan` varchar(200) NOT NULL,
  `berat_badan` varchar(200) NOT NULL,
  `tingkat_kesadaran` varchar(200) NOT NULL,
  `kepala_leher` varchar(200) NOT NULL,
  `jantung` varchar(200) NOT NULL,
  `paru-paru` varchar(200) NOT NULL,
  `perut` varchar(200) NOT NULL,
  `adema` varchar(200) NOT NULL,
  `icd_x` varchar(200) NOT NULL,
  `planing` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pendaftaran`
--

CREATE TABLE `tbl_pendaftaran` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(200) NOT NULL,
  `No_induk_keluarga` varchar(200) NOT NULL,
  `no_penduduk` varchar(200) NOT NULL,
  `tempat_tanggal_lahir` varchar(200) NOT NULL,
  `jenis_kelamin` varchar(200) NOT NULL,
  `alamat_lengkap` varchar(200) NOT NULL,
  `desa_kelurahan` varchar(200) NOT NULL,
  `Kabupaten_kota` varchar(200) NOT NULL,
  `agama` varchar(200) NOT NULL,
  `status_perkawinan` varchar(200) NOT NULL,
  `pendidikan_terakhir` varchar(200) NOT NULL,
  `Pekerjaan` varchar(200) NOT NULL,
  `kewargaraan` varchar(200) NOT NULL,
  `cara_pembayaran` varchar(200) NOT NULL,
  `no_kartu` varchar(200) NOT NULL,
  `nama_penanggung_jawab` varchar(200) NOT NULL,
  `No_telp_hp` varchar(200) NOT NULL,
  `asuransi` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poli_gigi`
--

CREATE TABLE `tbl_poli_gigi` (
  `id` int(11) NOT NULL,
  `iddtpasien` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `anamnesa` varchar(200) NOT NULL,
  `physic_diagnostic` varchar(200) NOT NULL,
  `tensi` varchar(200) NOT NULL,
  `nadi` varchar(200) NOT NULL,
  `suhu` varchar(200) NOT NULL,
  `laju_pernafasan` varchar(200) NOT NULL,
  `tinggi_badan` varchar(200) NOT NULL,
  `berat_badan` varchar(200) NOT NULL,
  `tingkat_kesadaran` varchar(200) NOT NULL,
  `kepala_leher` varchar(200) NOT NULL,
  `jantung` varchar(200) NOT NULL,
  `paru_paru` varchar(200) NOT NULL,
  `perut` varchar(200) NOT NULL,
  `adema` varchar(200) NOT NULL,
  `icd_x` varchar(200) NOT NULL,
  `planing` varchar(200) NOT NULL,
  `tanggal_kunjungan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_poli_gigi`
--

INSERT INTO `tbl_poli_gigi` (`id`, `iddtpasien`, `nama`, `anamnesa`, `physic_diagnostic`, `tensi`, `nadi`, `suhu`, `laju_pernafasan`, `tinggi_badan`, `berat_badan`, `tingkat_kesadaran`, `kepala_leher`, `jantung`, `paru_paru`, `perut`, `adema`, `icd_x`, `planing`, `tanggal_kunjungan`) VALUES
(1, 46, 'asdas', 'sds', 'hjgdshsj', 'jhgsjdh', 'jhgdfhs', 'jhgdhfsg', 'jhgdjfhs', 'jhdgjshd', 'jhdgfjshd', 'jhgdfjh', 'jhsgdfjhd', 'hgdfjhsd', 'jhdgfjhs', 'hjdgfjhds', 'jhdgfjhsd', 'jdhgf', 'jhsdfg', '2020-07-09');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poli_kia`
--

CREATE TABLE `tbl_poli_kia` (
  `id` int(11) NOT NULL,
  `iddtpasien` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `anamnesa` varchar(200) NOT NULL,
  `physic_diagnostic` varchar(200) NOT NULL,
  `tensi` varchar(200) NOT NULL,
  `nadi` varchar(200) NOT NULL,
  `suhu` varchar(200) NOT NULL,
  `laju_pernafasan` varchar(200) NOT NULL,
  `tinggi_badan` varchar(200) NOT NULL,
  `berat_badan` varchar(200) NOT NULL,
  `tingkat_kesadaran` varchar(200) NOT NULL,
  `kepala_leher` varchar(200) NOT NULL,
  `jantung` varchar(200) NOT NULL,
  `paru_paru` varchar(200) NOT NULL,
  `perut` varchar(200) NOT NULL,
  `adema` varchar(200) NOT NULL,
  `icd_x` varchar(200) NOT NULL,
  `planing` varchar(200) NOT NULL,
  `tanggal_kunjungan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_poli_kia`
--

INSERT INTO `tbl_poli_kia` (`id`, `iddtpasien`, `nama`, `anamnesa`, `physic_diagnostic`, `tensi`, `nadi`, `suhu`, `laju_pernafasan`, `tinggi_badan`, `berat_badan`, `tingkat_kesadaran`, `kepala_leher`, `jantung`, `paru_paru`, `perut`, `adema`, `icd_x`, `planing`, `tanggal_kunjungan`) VALUES
(1, 46, 'sssss', '', 'werw', 'werw', 'erw', 'erw', 'erw', 'erw', 'erw', 'erw', 'werw', 'er', 'erwe', 'rwerwe', 'ere', 'ere', 'ewe', '2020-07-01');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poli_mtbs`
--

CREATE TABLE `tbl_poli_mtbs` (
  `id` int(11) NOT NULL,
  `iddtpasien` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `anamnesa` varchar(200) NOT NULL,
  `physic_diagnostic` varchar(200) NOT NULL,
  `tensi` varchar(200) NOT NULL,
  `nadi` varchar(200) NOT NULL,
  `suhu` varchar(200) NOT NULL,
  `laju_pernafasan` varchar(200) NOT NULL,
  `tinggi_badan` varchar(200) NOT NULL,
  `berat_badan` varchar(200) NOT NULL,
  `tingkat_kesadaran` varchar(200) NOT NULL,
  `kepala_leher` varchar(200) NOT NULL,
  `jantung` varchar(200) NOT NULL,
  `paru_paru` varchar(200) NOT NULL,
  `perut` varchar(200) NOT NULL,
  `adema` varchar(200) NOT NULL,
  `ICD_X` varchar(200) NOT NULL,
  `planing` varchar(200) NOT NULL,
  `tanggal_kunjungan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_poli_mtbs`
--

INSERT INTO `tbl_poli_mtbs` (`id`, `iddtpasien`, `nama`, `anamnesa`, `physic_diagnostic`, `tensi`, `nadi`, `suhu`, `laju_pernafasan`, `tinggi_badan`, `berat_badan`, `tingkat_kesadaran`, `kepala_leher`, `jantung`, `paru_paru`, `perut`, `adema`, `ICD_X`, `planing`, `tanggal_kunjungan`) VALUES
(1, 46, 'eweuh', 'sd', 'uygy', 'km', 'kj', 'rdcr', 'j', 'imi', 'tfcr', 'jin', 'u', 'rtf', 'a', 'uyyt', 'sdfsd', 'fr', 'h', '2020-07-10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poli_pkpr`
--

CREATE TABLE `tbl_poli_pkpr` (
  `id` int(11) NOT NULL,
  `iddtpasien` int(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `anamnesa` varchar(200) NOT NULL,
  `physic_diagnostic` varchar(200) NOT NULL,
  `tensi` varchar(200) NOT NULL,
  `nadi` varchar(200) NOT NULL,
  `suhu` varchar(200) NOT NULL,
  `laju_pernafasan` varchar(200) NOT NULL,
  `tinggi_badan` varchar(200) NOT NULL,
  `berat_badan` varchar(200) NOT NULL,
  `tingkat_kesadaran` varchar(200) NOT NULL,
  `kepala_leher` varchar(200) NOT NULL,
  `jantung` varchar(200) NOT NULL,
  `paru_paru` varchar(200) NOT NULL,
  `perut` varchar(200) NOT NULL,
  `adema` varchar(200) NOT NULL,
  `icd_x` varchar(200) NOT NULL,
  `planing` varchar(200) NOT NULL,
  `tanggal_kunjungan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_poli_pkpr`
--

INSERT INTO `tbl_poli_pkpr` (`id`, `iddtpasien`, `nama`, `anamnesa`, `physic_diagnostic`, `tensi`, `nadi`, `suhu`, `laju_pernafasan`, `tinggi_badan`, `berat_badan`, `tingkat_kesadaran`, `kepala_leher`, `jantung`, `paru_paru`, `perut`, `adema`, `icd_x`, `planing`, `tanggal_kunjungan`) VALUES
(1, 50, 'ssss', '', 'sdfs', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfsd', 'sdfds', 'vdf', 'sdfsd', 'sfsd', 'sdsd', 'sdfsd', 'sdfsd', 'sdfsd', '2020-07-10');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_poli_umum`
--

CREATE TABLE `tbl_poli_umum` (
  `id` int(11) NOT NULL,
  `iddtpasien` int(11) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `anamnesa` varchar(128) NOT NULL,
  `physic_diagnostic` varchar(128) NOT NULL,
  `tensi` varchar(128) NOT NULL,
  `nadi` varchar(128) NOT NULL,
  `suhu` varchar(128) NOT NULL,
  `laju_pernafasan` varchar(128) NOT NULL,
  `tinggi_badan` varchar(128) NOT NULL,
  `berat_badan` varchar(128) NOT NULL,
  `tingkat_kesadaran` varchar(128) NOT NULL,
  `kepala_leher` varchar(128) NOT NULL,
  `jantung` varchar(128) NOT NULL,
  `paru_paru` varchar(128) NOT NULL,
  `perut` varchar(128) NOT NULL,
  `adema` varchar(128) NOT NULL,
  `ICD_X` varchar(128) NOT NULL,
  `planing` varchar(128) NOT NULL,
  `tanggal_kunjungan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_poli_umum`
--

INSERT INTO `tbl_poli_umum` (`id`, `iddtpasien`, `nama`, `anamnesa`, `physic_diagnostic`, `tensi`, `nadi`, `suhu`, `laju_pernafasan`, `tinggi_badan`, `berat_badan`, `tingkat_kesadaran`, `kepala_leher`, `jantung`, `paru_paru`, `perut`, `adema`, `ICD_X`, `planing`, `tanggal_kunjungan`) VALUES
(3, 46, 'hgf', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00'),
(4, 50, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `image` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `role_id` int(11) NOT NULL,
  `is_active` int(1) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `image`, `password`, `role_id`, `is_active`, `date_created`) VALUES
(1, 'h', 'ichan@gmail.com', 'default.jpg ', '$2y$10$RU5c5MjhlrXQ2W6CRIzvp.b7aOlIxudncilxpsbgqgLIbpIRsxnPK', 2, 1, 1592692299),
(2, 'ichan', 'kichani@gmail.com', 'default.jpg ', '$2y$10$BoNCn5XQKAd8yNeVFEmYReAqRs9RYaejM2UBXfLLS7o1ACCXgCyxm', 1, 1, 1592819256);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(150) NOT NULL,
  `is_active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `is_active`) VALUES
('5f04492b24426', 'kambing15', '$2y$10$Q0.09X1zDytfmQkNWgxSD.McJqlXs8EQpjS1Wuy1PmvJB7Fv95IFu', 1),
('5f044981a0a2c', 'ntah', '$2y$10$3FcirC9cUkQF/hIutPvkk.lb3yHJaeJ9.f4vfLTsngrWLMsG8eFU2', 1),
('5f0464d121a1c', 'ichan03', '$2y$10$oacuqQVTUUk9Fypu7uNB/.ffKE1i9jAfDUbx8R7Dy72N3qiUIUe3.', 1),
('5f04654368122', 'kichani00', '$2y$10$nJ80zlCd68ZTq1ToCw/gjuJvy5IWSZaaI/GKnJRzQfPenaE4EI/9i', 1),
('5f0465d43ebda', 'yuli00', '$2y$10$p0FdPGPWh8RaLWerHfPMSOip/kT4iX5eDsO3sKvjc/onJMjQggJgW', 1),
('5f055a39020e3', 'Rizka', '$2y$10$HAp0.sdoQt3wdxxubpaVaeqwNmGtBb7irS1VgR/cvGJG9huJ.HtaO', 1),
('5f055a834a80e', 'rizkaRR', '$2y$10$RyK4t8H6EMuq1LywjwkDP.VbKdiOnk8c3XsqUTIl1jwQYrWmCWuHi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` varchar(50) NOT NULL,
  `uid` varchar(50) NOT NULL,
  `nama_lengkap` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `photo` varchar(150) NOT NULL,
  `role` enum('admin','dokter;poli umum','dokter;poli gigi','dokter;poli mtbs','dokter;poli pkpr','dokter;poli kia') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `uid`, `nama_lengkap`, `email`, `photo`, `role`, `created_at`) VALUES
('5f04492b451a0', '5f04492b24426', 'kambing', 'k@mail.com', 'default.jpg', 'dokter;poli umum', '2020-07-07 04:06:35'),
('5f044981c2733', '5f044981a0a2c', 'ntah', 'ntah@mail.com', 'default.jpg', 'admin', '2020-07-07 10:08:01'),
('5f0464d13fc15', '5f0464d121a1c', 'ichan', 'ichan@gmail.com', 'default.jpg', 'dokter;poli kia', '2020-07-07 12:04:33'),
('5f04654386bd7', '5f04654368122', 'kichani', 'kichani@gmail.com', 'default.jpg', 'admin', '2020-07-07 12:06:27'),
('5f0465d45cfa4', '5f0465d43ebda', 'yuli', 'yuli@gmail.com', 'default.jpg', 'admin', '2020-07-07 12:08:52'),
('5f055a39255cc', '5f055a39020e3', 'rizka', 'rizka@gmail.com', 'default.jpg', 'dokter;poli kia', '2020-07-08 05:31:37'),
('5f055a836e37e', '5f055a834a80e', 'rizka', 'rizkaa@gmail.com', 'default.jpg', 'dokter;poli kia', '2020-07-08 05:32:51');

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', 1),
(2, 2, 'Profil Admin', 'user', 'far fa-fw fa-user', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_data_pasien`
--
ALTER TABLE `tbl_data_pasien`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pendaftaran`
--
ALTER TABLE `tbl_pendaftaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_poli_gigi`
--
ALTER TABLE `tbl_poli_gigi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t3` (`iddtpasien`);

--
-- Indexes for table `tbl_poli_kia`
--
ALTER TABLE `tbl_poli_kia`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t4` (`iddtpasien`);

--
-- Indexes for table `tbl_poli_mtbs`
--
ALTER TABLE `tbl_poli_mtbs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t2` (`iddtpasien`);

--
-- Indexes for table `tbl_poli_pkpr`
--
ALTER TABLE `tbl_poli_pkpr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t5` (`iddtpasien`);

--
-- Indexes for table `tbl_poli_umum`
--
ALTER TABLE `tbl_poli_umum`
  ADD PRIMARY KEY (`id`),
  ADD KEY `t1` (`iddtpasien`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_data_pasien`
--
ALTER TABLE `tbl_data_pasien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tbl_pendaftaran`
--
ALTER TABLE `tbl_pendaftaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_poli_gigi`
--
ALTER TABLE `tbl_poli_gigi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_poli_kia`
--
ALTER TABLE `tbl_poli_kia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_poli_mtbs`
--
ALTER TABLE `tbl_poli_mtbs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_poli_pkpr`
--
ALTER TABLE `tbl_poli_pkpr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_poli_umum`
--
ALTER TABLE `tbl_poli_umum`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_poli_gigi`
--
ALTER TABLE `tbl_poli_gigi`
  ADD CONSTRAINT `t3` FOREIGN KEY (`iddtpasien`) REFERENCES `tbl_data_pasien` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_poli_kia`
--
ALTER TABLE `tbl_poli_kia`
  ADD CONSTRAINT `t4` FOREIGN KEY (`iddtpasien`) REFERENCES `tbl_data_pasien` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_poli_mtbs`
--
ALTER TABLE `tbl_poli_mtbs`
  ADD CONSTRAINT `t2` FOREIGN KEY (`iddtpasien`) REFERENCES `tbl_data_pasien` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_poli_pkpr`
--
ALTER TABLE `tbl_poli_pkpr`
  ADD CONSTRAINT `t5` FOREIGN KEY (`iddtpasien`) REFERENCES `tbl_data_pasien` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_poli_umum`
--
ALTER TABLE `tbl_poli_umum`
  ADD CONSTRAINT `t1` FOREIGN KEY (`iddtpasien`) REFERENCES `tbl_data_pasien` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_info`
--
ALTER TABLE `user_info`
  ADD CONSTRAINT `user_info_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
