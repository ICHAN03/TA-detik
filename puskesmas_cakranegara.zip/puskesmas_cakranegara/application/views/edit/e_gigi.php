<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header " style="background-color: blue"></div>
            <div class="card-body">

                <form action="<?= site_url('admin/p_editG/') ?>" method="post">
                    <div class="form-group">

                    
                    <<div class="form-group">
                            <label>ID Pasien</label>
                            <input type="text" class="form-control" name="pasien" value="<?= $umum->id ?>" readonly>
                        </div>

                        <label>Nama Pasien </label>
                        <input type="text" class="form-control" name="iddtpasien" value="<?= $umum->iddtpasien; ?>"
                            autocomplete="off">
                            <label>anamnesa</label>
                        <input type="text" class="form-control" name="anemnesa" value="<?= $umum->anamnesa; ?>"
                            autocomplete="off"> 
                            <label>physic diagnostic</label>
                        <input type="text" class="form-control" name="diagnostic" value="<?= $umum->physic_diagnostic; ?>"
                            autocomplete="off"> 
                            <label>tensi</label>
                        <input type="text" class="form-control" name="tensi" value="<?= $umum->tensi; ?>"
                            autocomplete="off"> 
                            <label>nadi</label>
                        <input type="text" class="form-control" name="nadi" value="<?= $umum->nadi; ?>"
                            autocomplete="off"> 
                            <label>suhu</label>
                        <input type="text" class="form-control" name="suhu" value="<?= $umum->suhu; ?>"
                            autocomplete="off"> 
                            <label>laju pernafasan</label>
                        <input type="text" class="form-control" name="laju" value="<?= $umum->laju_pernafasan; ?>"
                            autocomplete="off"> 
                            <label>tinggi badan</label>
                        <input type="text" class="form-control" name="tinggi_badan" value="<?= $umum->tinggi_badan; ?>"
                            autocomplete="off">
                            <label>berat badan</label>
                            <input type="text" class="form-control" name="berat_badan" value="<?= $umum->berat_badan; ?>"
                            autocomplete="off">
                            <label>tingkat kesadaran</label>
                        <input type="text" class="form-control" name="tingat_kesadaran"value="<?= $umum->tingkat_kesadaran; ?>"
                            autocomplete="off">
                            <label>kepala leher</label>
                            <input type="text" class="form-control" name="kepala" value="<?= $umum->kepala_leher; ?>"
                            autocomplete="off">
                            <label>jatung</label>
                        <input type="text" class="form-control" name="jatung"value="<?= $umum->jatung; ?>"
                            autocomplete="off">
                            <label>paru</label>
                            <input type="text" class="form-control" name="paru_paru" value="<?= $umum->paru_paru; ?>"
                            autocomplete="off">
                            <label>perut</label>
                        <input type="text" class="form-control" name="perut"value="<?= $pasien->perut; ?>"
                            autocomplete="off">
                            <label>adema</label>
                            <input type="text" class="form-control" name="adema"value="<?= $pasien->adema; ?>"
                            autocomplete="off">
                                <label>icd</label>
                        <input type="text" class="form-control" name="icd"value="<?= $pasien->icd_x; ?>"
                            autocomplete="off">
                            <label>planing</label>
                        <input type="text" class="form-control" name="plaming"value="<?= $pasien->planing; ?>"
                            autocomplete="off">
                            <label>tanggal Kunjungan</label>
                        <input type="text" class="form-control" name="tanggal"value="<?= $pasien->tanggla_kunjungan; ?>"
                            autocomplete="off">
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?= $umum->id; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>

            </div>
        </div>
    </div>
</div>
</div>