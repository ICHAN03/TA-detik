<?php
class pasien_model extends CI_Model
{
    public function getAll(){
        return $this->db->get('tbl_data_pasien')->result();
    }
}
