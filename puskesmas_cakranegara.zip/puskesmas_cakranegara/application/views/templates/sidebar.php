  <!-- Sidebar -->
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
  <div class="sidebar-brand-icon rotate-n-15">
  <i class="fas fa-hospital-alt"></i>
  </div>
  <div class="sidebar-brand-text mx-3"> Puskesmas Cakranegara </div>
</a>

<!-- Divider -->
<hr class="sidebar-divider">

<?php  

  if($this->session->userdata('role') == 'admin'):

?>
<!-- Heading -->
<div class="sidebar-heading">
 ADMIN
</div>
<!-- Nav Item - Dashboard -->
<li class="nav-item active">
  <a class="nav-link" href="<?php echo base_url().'index.php/Admin'; ?>">
    <i class="fas fa-fw fa-tachometer-alt"></i>
    <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
 
</div>

<li class="nav-item active">
        <a class="nav-link" href="<?=site_url("Admin/pendaftaran")?>">
        <i class="far fa-fw fa-user"></i>
          <span>Pendaftaran</span></a>

<!-- Divider -->
<hr class="sidebar-divider">
<!-- <hr class="sidebar-divider"> -->
<li class="nav-item active">
        <a class="nav-link" href="<?=site_url("Admin/pasien")?>">
        <i class="fas fa_fw fa-database"></i>
          <span>Data Pasien</span></a>

<!-- <li class="nav-item active">
        <a class="nav-link" href="<?=site_url("Admin/coba")?>">
        <i class="fas fa_fw fa-database"></i>
          <span>Data Pasien</span></a> -->
          
        <!-- php -->
        <!-- Divider -->
      <hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
  USER
</div>

<li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-folder"></i>
          <span>POLI</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">POLI</h6>
            <a class="collapse-item" href="<?= site_url('admin/umum')?>">POLI UMUM</a>
      <a class="collapse-item" href="<?= site_url('admin/mtbs')?>">POLI MTBS</a>
      <a class="collapse-item" href="<?= site_url('admin/pkpr')?>">POLI PKPR</a>
      <a class="collapse-item" href="<?= site_url('admin/kia')?>">POLI KIA/KB</a>
      <a class="collapse-item" href="<?= site_url('admin/gigi')?>">POLI GIGI</a>
          </div>
        </div>
      </li>


  <?php elseif($this->session->userdata('role') == 'dokter'): ?>
    <li class="nav-item active">
  <a class="nav-link" href="#">
  <i class="fas fa-fw fa-file-alt"></i>
    <span><?php echo ucfirst($this->session->userdata('poli')) ?></span></a>
</li>
  
  <?php endif?>
   <!-- Nav Item - Charts -->
<li class="nav-item active">
  <a class="nav-link" href="charts.html">
  <i class="fas fa-fw fa-file-alt"></i>
    <span>Laporan</span></a>
</li>
      <!-- Divider -->
<hr class="sidebar-divider">
<!-- Heading -->
<div class="sidebar-heading">    
Graph data
</div>

<!-- Nav Item - Charts -->
<!-- <li class="nav-item active">
  <a class="nav-link" href="<?= site_url('admin/grafik')?>">
    <i class="fas fa-fw fa-chart-area"></i>
    <span>Charts</span></a>
</li> -->

<li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Charts</h6>
            <a class="collapse-item" href="<?= site_url('admin/grafik')?>">Data Pasien</a>
            <a class="collapse-item" href="<?= site_url('admin/grafikUmum')?>">POLI UMUM</a>
            <a class="collapse-item" href="<?= site_url('admin/grafikMtbs')?>">POLI MTBS</a>
            <a class="collapse-item" href="utilities-other.html">POLI PKPR</a>
            <a class="collapse-item" href="utilities-other.html">POLI KIA/KB</a>
            <a class="collapse-item" href="utilities-other.html">POLI GIGI</a>
          </div>
        </div>
      </li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
  <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul>
<!-- End of Sidebar -->
