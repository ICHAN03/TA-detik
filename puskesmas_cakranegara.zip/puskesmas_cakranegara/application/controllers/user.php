<?php
defined('BASEPATH') or exit('No direct script accesss allowed');

class user extends CI_Controller
{
public function index()
{
    $data['title'] = 'USER';
   $this->load->view('templates/header',$data);
   $this->load->view('templates/sidebar',$data);
   $this->load->view('templates/topbar',$data);
   $this->load->view('user/index',$data);
   $this->load->view('templates/footer');
}

function profile(){
//   Sementara
        $data['title'] = 'PROFIL';
        
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar',$data);
        $this->load->view('templates/topbar',$data);
        $this->load->view('admin/profil',$data);
        $this->load->view('templates/footer');
}
}