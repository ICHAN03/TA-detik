
<!DOCTYPE html>
<html>

<head>
    <title>Export Data Ke Excel Dengan PHP - www.malasngoding.com</title>
</head>
<section class="content-header">
     
    <style type="text/css">
    body {
        font-family: sans-serif;
    }

    table {
        margin: 20px auto;
        border-collapse: collapse;
    }

    /* table th,
    table td {
        border: 1px solid #3c3c3c;
        padding: 3px 8px;

    } */

    /* a {
        background: blue;
        color: #fff;
        padding: 8px 10px;
        text-decoration: none;
        border-radius: 2px;
    } */
    </style>
      <table class="table">
         <div class="form-group">
              <input type="hidden" name="id" herf="<?= site_url().$detail->id; ?>">
         </div>
         <h1>DINAS KESEHATAN KOTA MATARAM</h1>
            <h1>PUSKEMAS CAKRANEGARA</h1>
         <h1>LAPORAN KARTU JALAN POLI KIA</h1>
     <h1>_________________________________</h1>
         <center>
        <a target="_blank" href="<?= site_url() . '//test' ?>">EXPORT KE EXCEL</a>
    </center>
                              
     <tr>                             
     <td>Tanggal Kunjungan</td>                            
     <td>:</td>                           
     <td><?php echo $detail->tanggal_kunjungan ?></td>
      </tr>
     
     <tr>                           
     <td>No Rekam Medis</td>                           
     <td>:</td>                           
     <td><?php echo $detail->no_rekam_medis ?></td>
     </tr>
     
     <tr>                            
     <td>Nama</td>                          
     <td>:</td>                          
     <td><?php echo $detail->nama_lengkap ?></td>
     </tr>
      
     <tr>                            
     <td>No KK</td>                            
     <td>:</td>                             
     <td><?php echo $detail->nokk ?></td>
     </tr>
     
     <tr>                            
     <td>Nama Penanggung Jawab</td>                            
     <td>:</td>                             
     <td><?php echo $detail->nama_penanggung_jawab ?></td>
     </tr>
     
     <tr>                            
     <td>NIK</td>                            
     <td>:</td>                             
     <td><?php echo $detail->NIK ?></td>
     </tr>
     
     <tr>                            
     <td>Alamat</td>                            
     <td>:</td>                             
     <td><?php echo $detail->alamat ?></td>
     </tr>
          
     <tr>                            
     <td>Tinggal Lahir</td>                            
     <td>:</td>                             
     <td><?php echo $detail->tanggal_lahir ?></td>
     </tr>
     
     <tr>                            
     <td>Jenis Kelamin</td>                            
     <td>:</td>                             
     <td><?php echo $detail->jenis_kelamin ?></td>
     </tr>
     
     <tr>                            
     <td>No Identitas</td>                            
     <td>:</td>                             
     <td><?php echo $detail->no_identitas ?></td>
     </tr>
     
     <tr>                            
     <td>Agama</td>                            
     <td>:</td>                             
     <td><?php echo $detail->agama ?></td>
     </tr>   
     
     <tr>                            
     <td>Pendidikan</td>                            
     <td>:</td>                             
     <td><?php echo $detail->pendidikan ?></td>
     </tr> 
     
     <tr>                            
     <td>Status Perkawinan</td>                            
     <td>:</td>                             
     <td><?php echo $detail->status_perkawinan ?></td>
     </tr>   
     
     <tr>                            
     <td>No Kartu JKN</td>                            
     <td>:</td>                             
     <td><?php echo $detail->no_kartu_jkn ?></td>
     </tr>  
     
     <tr>                            
     <td>Cara Bayar</td>                            
     <td>:</td>                             
     <td><?php echo $detail->cara_pembayaran ?></td>
     </tr>   
     
     </table>
      
                          
     <div class="box-footer">
                             <!-- <?php echo anchor('mahasiswa', 'cancel', array('class' => 'btn btn-default'));
                             ?> -->
                         </div>
      
                     </div>
      
                     <!-- /.box-body -->
                 </div>
      
                 <!-- /.box -->
      
             </div>
      
             <!--/.col (right) -->
         </div>
      
         <!-- /.row -->
     </section>
      
     <!-- /.content -->