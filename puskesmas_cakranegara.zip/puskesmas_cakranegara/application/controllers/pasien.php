<?php
defined('BASEPATH') or exit('No direct script accesss allowed');

class pasien extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->model('pasien_model');
      
    }
    public function pasien()
    {
        // // $data['user']= $this->db->get_where('user',['email'=> 
        // // $this->session->userdata('email')])->row_array();
        // $data['pasien'] = $this->pasien_model->getAll();
        
        $this->load->view('templates/header');
        $this->load->view('templates/sidebar');
        $this->load->view('templates/topbar');
        $this->load->view('input/i_data_pasien');
        $this->load->view('templates/footer');
    }
}