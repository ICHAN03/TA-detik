      

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-900"><?=$title?></h1>

<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

