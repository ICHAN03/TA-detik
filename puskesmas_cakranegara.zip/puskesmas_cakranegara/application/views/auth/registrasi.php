<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-7 mx-auto">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <div class="col-lg">
                    <div class="p-5">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">Create an Account!</h1>
                        </div>
                        <form class="user" method="post" action="<?= site_url('Auth/registrasi'); ?>">
                            <div class="form-group">
                                <input type="text"  id="name" class="form-control form-control-user" name="name" placeholder="Full Name" autocomplete="off" value="<?= set_value('name'); ?>">
                                <?= form_error('name', '<small class="text_danger pl-2">', '</small>'); ?>

                            </div>
                            <div class="form-group">
                                <input type="text" name="username" placeholder="Username" id="username" class="form-control form-control-user">
                                <?= form_error('username', '<small class="text_danger pl-2">', '</small>'); ?>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control form-control-user" id="email" placeholder="Email Address" name="email" autocomplete="off" value="<?= set_value('email'); ?>">
                                <?= form_error('email', '<small class="text_danger pl-2">', '</small>'); ?>

                            </div>
                            <div class="form-group row">
                                <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="password" class="form-control form-control-user" id="password1" name="password" placeholder="Password">
                                </div>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control form-control-user" id="password2" name="password2" placeholder="Repeat Password">
                                    <small class = "text-danger" id='passErr'></small>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="role" class="control-label">Pilih Jenis User</label>
                                <select name="role" id="role" class="form-control">
                                    <option value="admin">Admin</option>
                                    <option value="poli umum">Poli Umum</option>
                                    <option value="poli gigi">Poli Gigi</option>
                                    <option value="poli mtbs">Poli MTBS</option>
                                    <option value="poli pkpr">Poli PKPR</option>
                                    <option value="poli kia">Poli KIA/KB</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary btn-user btn-block">
                                Register Account
                            </button>
                        </form>
                        <hr>
                        <div class="text-center">
                            <a class="small" href="forgot-password.html">Forgot Password?</a>
                        </div>
                        <div class="text-center">
                            <a class="small" href="<?= site_url('auth') ?>">Already have an account? Login!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
    function cekPassword(){
        const password = $('#password1').val();
        const ini = $(this);

        if(ini.val() != password)
            $('#passErr').html('Password Tidak Sama').show();
        else
            $('#passErr').html('').hide();
    }

    $("#password2").keyup(cekPassword);

</script>