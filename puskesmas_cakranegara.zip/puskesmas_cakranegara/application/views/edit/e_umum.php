<!-- <?php
echo '<script type="text/javascript">';
echo "let pasien = " . json_encode($pasien->id) . "\n";
echo '</script>';

 ?> -->
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header " style="background-color: blue"></div>
            <div class="card-body">

                <form action="<?= site_url('admin/p_editU/') ?>" method="post">
                <div class="modal-body">
                    <div class="form-group">

                        <div class="form-group">
                            <label>ID Poli</label>
                            <input type="text" class="form-control" name="pasien" value="<?= $umum->id ?>" readonly>
                        </div>

                            <label>Nama </label>
                        <input type="text" class="form-control" name="nama" value="<?= $umum->nama; ?>"
                            autocomplete="off">
                            <label>anamnesa</label>
                        <input type="text" class="form-control" name="anamnesa" value="<?= $umum->anamnesa; ?>"
                            autocomplete="off"> 
                            <label>physic diagnostic</label>
                        <input type="text" class="form-control" name="diagnostic" value="<?= $umum->physic_diagnostic; ?>"
                            autocomplete="off"> 
                            <label>tensi</label>
                        <input type="text" class="form-control" name="tensi" value="<?= $umum->tensi; ?>"
                            autocomplete="off"> 
                            <label>nadi</label>
                        <input type="text" class="form-control" name="nadi" value="<?= $umum->nadi; ?>"
                            autocomplete="off"> 
                            <label>suhu</label>
                        <input type="text" class="form-control" name="suhu" value="<?= $umum->suhu; ?>"
                            autocomplete="off"> 
                            <label>laju pernafasan</label>
                        <input type="text" class="form-control" name="laju" value="<?= $umum->laju_pernafasan; ?>"
                            autocomplete="off"> 
                            <label>tinggi badan</label>
                        <input type="text" class="form-control" name="tinggi_badan" value="<?= $umum->tinggi_badan; ?>"
                            autocomplete="off">
                            <label>berat badan</label>
                            <input type="text" class="form-control" name="berat_badan" value="<?= $umum->berat_badan; ?>"
                            autocomplete="off">
                            <label>tingkat kesadaran</label>
                        <input type="text" class="form-control" name="tingkat_kesadaran"value="<?= $umum->tingkat_kesadaran; ?>"
                            autocomplete="off">
                            <label>kepala leher</label>
                            <input type="text" class="form-control" name="kepala" value="<?= $umum->kepala_leher; ?>"
                            autocomplete="off">
                            <label>jantung</label>
                        <input type="text" class="form-control" name="jantung"value="<?= $umum->jantung; ?>"
                            autocomplete="off">
                            <label>paru</label>
                            <input type="text" class="form-control" name="paru_paru" value="<?= $umum->paru_paru; ?>"
                            autocomplete="off">
                            <label>perut</label>
                        <input type="text" class="form-control" name="perut"value="<?= $umum->perut; ?>"
                            autocomplete="off">
                            <label>adema</label>
                            <input type="text" class="form-control" name="adema"value="<?= $umum->adema; ?>"
                            autocomplete="off">
                                <label>icd</label>
                        <input type="text" class="form-control" name="icd"value="<?= $umum->ICD_X; ?>"
                            autocomplete="off">
                            <label>planing</label>
                        <input type="text" class="form-control" name="planing"value="<?= $umum->planing; ?>"
                            autocomplete="off">
                            <label>tanggal Kunjungan</label>
                        <input type="date" class="form-control" name="tanggal"value="<?= $umum->tanggal_kunjungan; ?>"
                            autocomplete="off">
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?= $umum->id; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>

            </div>
        </div>
    </div>
</div>
</div>
<script>

let pasien = document.querySelectorAll('#pasien option');
pasien.forEach(umum => 'iddtpasien' {

    if (item.value == umum) {
        item.selected = true;
    }
    console.log(item.value);
})
</script>