<!DOCTYPE html>
<html>

<head>
    <title>Export Data Ke Excel Dengan PHP - www.malasngoding.com</title>
</head>

<body>
    <style type="text/css">
    body {
        font-family: sans-serif;
    }

    table {
        margin: 20px auto;
        border-collapse: collapse;
    }

    table th,
    table td {
        border: 1px solid #3c3c3c;
        padding: 3px 8px;

    }

    a {
        background: blue;
        color: #fff;
        padding: 8px 10px;
        text-decoration: none;
        border-radius: 2px;
    }
    </style>
       <h1>DINAS KESEHATAN KOTA MATARAM</h1>
            <h1>PUSKEMAS CAKRANEGARA</h1>
         <h1>LAPORAN KARTU JALAN POLI PKPR</h1>
     <h1>_________________________________</h1>

    <center>
        <a target="_blank" href="<?= site_url() . '//test' ?>">EXPORT KE EXCEL</a>
    </center>

    <table>
        <tr>
        <th>No</th>
        <th>ID Poli</th>
        <th>Nama</th>
        <th>Anamenesa</th>
        <th>physic_diagnostic</th>
        <th>Tensi</th>
        <th>Nadi</th>
        <th>Suhu</th>
        <th>Laju Pernafasan</th>
        <th>Tinggi Badan</th>
        <th>Berat Badan</th>
        <th>Tingkat Kesadaran</th>
        <th>Kepala Leher</th>
        <th>jantung</th>
        <th>Paru-Paru</th>
        <th>Perut</th>
        <th>Adema</th>
        <th>ICD_X</th>
        <th>Planing</th>
        <th>Tangaal Kunjungan</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Sulaiman</td>
            <td>Jakarta</td>
            <td>0829121223</td>
        </tr>
        <tr>
            <td>2</td>
            <td>Diki Alfarabi Hadi</td>
            <td>Jakarta</td>
            <td>08291212211</td>
        </tr>
        <tr>
            <td>3</td>
            <td>Zakaria</td>
            <td>Medan</td>
            <td>0829121223</td>
        </tr>
        <tr>
            <td>4</td>
            <td>Alvinur</td>
            <td>Jakarta</td>
            <td>02133324344</td>
        </tr>
        <tr>
            <td>5</td>
            <td>Muhammad Rizani</td>
            <td>Jakarta</td>
            <td>08231111223</td>
        </tr>
        <tr>
            <td>6</td>
            <td>Rizaldi Waloni</td>
            <td>Jakarta</td>
            <td>027373733</td>
        </tr>
        <tr>
            <td>7</td>
            <td>Ferdian</td>
            <td>Jakarta</td>
            <td>0829121223</td>
        </tr>
        <tr>
            <td>8</td>
            <td>Fatimah</td>
            <td>Jakarta</td>
            <td>23432423423</td>
        </tr>
        <tr>
            <td>9</td>
            <td>Aminah</td>
            <td>Jakarta</td>
            <td>0829234233</td>
        </tr>
        <tr>
            <td>10</td>
            <td>Jafarudin</td>
            <td>Jakarta</td>
            <td>0829239323</td>
        </tr>
    </table>
</body>

</html>